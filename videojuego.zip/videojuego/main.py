import pygame
import random
import sys

# ========================
# Configuración inicial
# ========================
WIDTH = 800
HEIGHT = 600
FPS = 60

# Colores (RGB)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
ORANGE = (250,156,28)

# Inicializar Pygame y la ventana
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("ERIC GAME - Ampliació 4: Menú i Reinici")
clock = pygame.time.Clock()
font = pygame.font.SysFont("Arial", 30)
font2 = pygame.font.SysFont("Arial", 64)
font3 = pygame.font.SysFont("ATC Citrine", 50)
# Cargar sonidos
shoot_sound = pygame.mixer.Sound("shoot.wav")
muere = pygame.mixer.Sound("aguila.mp3")
medan = pygame.mixer.Sound("grito.mp3")
pygame.mixer.music.load("musica_menu.mp3")

# ========================
# Cargar la imagen de fondo
# ========================
background = pygame.image.load("background.jpg").convert()
menu_background = pygame.image.load("background1.jpg").convert()
menu_background2 = pygame.image.load("yo2.webp").convert()
muerte = pygame.image.load("muerte.webp").convert()
obstacle_hit_image = pygame.image.load("plumas1.png").convert()


# ========================
# Variables Globales del Juego
# ========================
score = 0
difficulty_level = 1
lives = 5
last_difficulty_update_time = pygame.time.get_ticks()
spawn_interval = 1500
ADD_OBSTACLE = pygame.USEREVENT + 1
paused = False  # Variable para pausar el juego
colorbala = True
# ========================
# Funciones Auxiliares
# ========================
def draw_text(surface, text, font, color, x, y):
    """Dibuja un texto en la pantalla."""
    text_obj = font.render(text, True, color)
    surface.blit(text_obj, (x, y))

# ========================
# Clases del Juego
# ========================
class Player(pygame.sprite.Sprite):
    """Clase para el jugador."""

    def __init__(self):
        super().__init__()
        # Cargar la imagen del jugador
        self.image = pygame.image.load("yo.png").convert_alpha()
        self.image = pygame.transform.scale(self.image, (170, 170 ))
        self.rect = self.image.get_rect()
        self.rect.center = (100, HEIGHT // 2)
        self.speed = 8

        self.dead_image = pygame.image.load("muerte.webp").convert_alpha()
        self.dead_image = pygame.transform.scale(self.dead_image, (170, 170))

        self.is_dead = False
        self.death_time = None
        self.death_duration = 10000




    def update(self):
        """Actualiza la posición del jugador según las teclas presionadas."""
        if paused:
            return  # No actualizar la posición si el juego está pausado

        if self.is_dead:
            if pygame.time.get_ticks() - self.death_time > self.death_duration:
                # Después de que pase la duración de la muerte, reiniciar el juego
                self.is_dead = False
                self.rect.center = (100, HEIGHT // 2)  # Reposicionar al jugador
                self.image = pygame.image.load("yo.png").convert_alpha()
                self.image = pygame.transform.scale(self.image, (170, 170))
            return  # Detener la actualización si está muerto

        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP]:
            self.rect.y -= self.speed
        if keys[pygame.K_DOWN]:
            self.rect.y += self.speed
        if keys[pygame.K_LEFT]:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT]:
            self.rect.x += self.speed

        # Evitar que el jugador salga de la pantalla
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > WIDTH:
            self.rect.right = WIDTH
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > HEIGHT:
            self.rect.bottom = HEIGHT

    def die(self):
        """Método que se llama cuando el jugador pierde todas sus vidas."""
        self.is_dead = True
        self.death_time = pygame.time.get_ticks()  # Guardar el tiempo de muerte
        self.image = self.dead_image  # Cambiar a la imagen de muerte


class Obstacle(pygame.sprite.Sprite):
    """Clase para los obstáculos."""

    def get_hit(self):
        """Método que se llama cuando el obstáculo es golpeado por una bala."""
        self.is_hit = True  # Marca el obstáculo como golpeado
        self.image = self.hit_image
        self.hit_timer = pygame.time.get_ticks()

    def __init__(self):
        super().__init__()
        # Cargar la imagen del obstáculo
        self.image = pygame.image.load("aguila.webp").convert_alpha()
        self.hit_image = pygame.image.load("plumas1.png").convert_alpha()
        self.is_hit = False  # Nuevo atributo para saber si fue golpeado
        self.hit_timer = None


        # Generar un tamaño aleatorio para el obstáculo entre un rango
        width = random.randint(100,150)
        height = width


        # Escalar la imagen a un tamaño aleatorio
        self.image = pygame.transform.scale(self.image, (width, height))
        self.rect = self.image.get_rect()

        # Posición inicial: fuera de la pantalla por la derecha
        self.rect.x = WIDTH + random.randint(10, 100)
        self.rect.y = random.randint(0, HEIGHT - self.rect.height)

        # Velocidad aleatoria inicial para el movimiento en el eje X
        self.speed_x = random.randint(3 + difficulty_level, 7 + difficulty_level)

        # Velocidad aleatoria en el eje Y que cambia de manera no lineal
        self.speed_y = random.randint(-3, 3)  # Movimiento aleatorio en el eje Y

        # El movimiento será no lineal porque la velocidad en Y cambiará cada cierto tiempo
        self.change_y_time = random.randint(50, 150)  # Cada cuánto cambiará la velocidad en Y

        # Tiempo para cambiar la dirección en Y
        self.time_since_change = 0

    def update(self):
        """Actualiza la posición del obstáculo moviéndolo hacia la izquierda y de manera no lineal en Y."""
        if paused:
            return  # No actualizar si el juego está pausado
        if self.is_hit:
            self.image = self.hit_image
            if pygame.time.get_ticks() - self.hit_timer > 200:  # Mantener la imagen golpeada por 500ms
                self.kill()
            return  # Evita que el obstáculo siga moviéndose

        global score
        self.rect.x -= self.speed_x  # Movimiento constante en X

        # Actualización del movimiento en Y (no lineal)
        self.time_since_change += 1
        if self.time_since_change >= self.change_y_time:
            # Cambiar la velocidad en Y aleatoriamente
            self.speed_y = random.randint(-3, 3)
            self.time_since_change = 0  # Reiniciar el contador para cambiar la dirección en Y

        self.rect.y += self.speed_y  # Movimiento no lineal en Y

        # Evitar que el obstáculo se mueva fuera de la pantalla (en el eje Y)
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > HEIGHT:
            self.rect.bottom = HEIGHT



        # Cuando el obstáculo sale completamente de la pantalla, se incrementa la puntuación y se elimina
        if self.rect.right < 0:
            score += 1
            self.kill()




class Bullet(pygame.sprite.Sprite):
    """Clase para los disparos del jugador."""
    def __init__(self, x, y, bala):
        super().__init__()
        self.image = pygame.Surface((10, 5))
        self.image.fill(bala)
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.speed = 10

    def update(self):
        """Actualiza la posición del disparo."""
        if paused:
            return  # No actualizar si el juego está pausado

        self.rect.x += self.speed
        if self.rect.left > WIDTH:
            self.kill()  # Eliminar la bala si sale de la pantalla


# ========================
# Función para reiniciar el Juego
# ========================
def new_game():
    """Reinicia todas las variables y grupos para comenzar una nueva partida."""
    global score, difficulty_level, lives, last_difficulty_update_time, spawn_interval, all_sprites, obstacles, bullets, player
    score = 0
    difficulty_level = 1
    lives = 5
    last_difficulty_update_time = pygame.time.get_ticks()
    spawn_interval = 1500
    pygame.time.set_timer(ADD_OBSTACLE, spawn_interval)
    all_sprites = pygame.sprite.Group()
    obstacles = pygame.sprite.Group()
    bullets = pygame.sprite.Group()
    player = Player()
    all_sprites.add(player)


# ========================
# Función para mostrar el menú principal
# ========================
def show_menu():

    """Muestra la pantalla de menú de inicio y espera que el usuario presione alguna tecla para comenzar."""
    pygame.mixer.music.play(-1)  # Reproduce la música en bucle infinito
    waiting = True
    while waiting:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                waiting = False
        imagen = pygame.transform.scale(menu_background2, (800, 600))
        screen.blit(imagen, (0, 0))




        draw_text(screen, "ERIC GAME", font2, WHITE, 300, 60)
        draw_text(screen, "PULSA PARA COMENZAR", font3, WHITE, 250, 450)
        pygame.display.flip()


# ========================
# Función para ejecutar la partida
# ========================
def game_loop():
    """Ejecuta el bucle principal de la partida."""
    global score,difficulty_level, last_difficulty_update_time, spawn_interval, lives, paused, colorbala
    pygame.mixer.music.stop()
    new_game()
    game_state = "playing"
    running = True
    while running and game_state == "playing":
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    if colorbala:
                        bala = RED
                    else:
                        bala = ORANGE
                    # Disparar bala
                    colorbala = not colorbala
                    shoot_sound.play()  # Sonido de disparo
                    bullet = Bullet(player.rect.right, player.rect.centery -10,bala)
                    all_sprites.add(bullet)
                    bullets.add(bullet)

                elif event.key == pygame.K_p:

                    paused = not paused  # Pausar y reanudar el juego

            elif event.type == ADD_OBSTACLE:
                obstacle = Obstacle()
                all_sprites.add(obstacle)
                obstacles.add(obstacle)

        # Incrementar la dificultad cada 15 segundos
        current_time = pygame.time.get_ticks()
        if current_time - last_difficulty_update_time >= 15000:
            difficulty_level += 1
            last_difficulty_update_time = current_time
            spawn_interval = max(500, 1500 - (difficulty_level * 100))  # Aumentar la velocidad de aparición
            pygame.time.set_timer(ADD_OBSTACLE, spawn_interval)

        # Actualización de sprites
        all_sprites.update()

        # Colisiones entre balas y obstáculos
        hits = pygame.sprite.groupcollide(obstacles, bullets, False, True)
        if hits:
            muere.play()
            score+=1
            for obstacle in hits:
                obstacle.get_hit()



        # Colisiones entre jugador y obstáculos
        if pygame.sprite.spritecollideany(player, obstacles):
            medan.play()  # Reproducir sonido de colisión

        if pygame.sprite.spritecollideany(player, obstacles):
            lives -= 1
            if lives <= 0:
                player.die()
                game_state = "game_over"

            else:
                player.rect.center = (100,HEIGHT//2)
                for obs in obstacles:
                    obs.kill()
        # Dibujar todo en la pantalla

        screen.blit(background, (0, 0))  # Dibujar el fondo
        all_sprites.draw(screen)
        draw_text(screen, f"PUNTUACION: {score}", font, BLACK, 10, 10)
        draw_text(screen, f"VIDAS: {lives}", font, BLACK, 10, 40)
        draw_text(screen, f"DIFICULTAD: {difficulty_level}", font, BLACK, 10, 70)
        if paused:
            draw_text(screen, "PAUSA", font, WHITE, WIDTH // 2 - 50, HEIGHT // 2)

        pygame.display.flip()



    # Mostrar pantalla de Game Over
    if game_state == "game_over":
        show_game_over()


# ========================
# Función para mostrar la pantalla de Game Over
# ========================
def show_game_over():
    """Muestra la pantalla de Game Over y espera que el jugador presione una tecla para reiniciar."""
    waiting = True
    while waiting:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                waiting = False

        screen.blit(muerte, (0, 0))
        screen.blit(menu_background,(0,0))
        imagen = pygame.transform.scale(menu_background, (800, 600))
        screen.blit(imagen, (0, 0))


        draw_text(screen, "GAME OVER", font2, RED, 340, 20)
        draw_text(screen, "VUELVE A JUGAR", font2, BLACK, 300, 100)
        pygame.display.flip()


# ========================
# Ejecución del juego
# ========================

while True:
    show_menu()
    final_score = game_loop()
    show_game_over()

